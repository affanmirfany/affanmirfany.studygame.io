# Study Game 🎮📚

**Study Game** adalah platform belajar interaktif modern berbasis game (gamifikasi) yang dirancang untuk membuat proses belajar menjadi menyenangkan, menantang, dan adaptif layaknya bermain RPG/Game Petualangan Edukasi.

---

## 🎯 Tujuan Proyek
Mengubah paradigma belajar statis dan membosankan menjadi pengalaman interaktif di mana pengguna:
1. Memilih mata pelajaran dan topik belajar sesuai minat atau kurikulum.
2. Mengerjakan soal interaktif langsung dari antarmuka web yang intuitif.
3. Mendapatkan umpan balik (feedback) dan pembahasan cerdas seketika.
4. Mengembangkan karakter belajar dengan sistem **XP, Level, Streak, dan Topic Mastery (0–100%)**.
5. Mengalami **Adaptive Difficulty Engine** yang menyesuaikan tingkat kesulitan secara real-time berdasarkan performa.
6. Menjalani sesi **Remedial** saat menemui materi yang sulit dan membuka mode **Challenge & Boss Battle** saat mencapai Mastery $\ge 80\%$.

---

## 🌟 Fitur Utama

### 1. Game & Progression System
- **XP Rewards**:
  - *Easy*: 10 XP
  - *Medium*: 20 XP
  - *Hard*: 30 XP
  - *Challenge*: 40 XP
  - *Boss Question*: 100 XP
- **Streak System**: Jawaban benar berturut-turut meningkatkan streak dan memberikan bonus multiplier. Jawaban salah mereset streak menjadi 0.
- **Level Progression**: XP dikonversi menjadi level dengan kurva perkembangan yang memotivasi.
- **Topic Mastery**: Skala 0–100% pada setiap topik materi yang bertambah saat menjawab benar dan berkurang secara proporsional saat keliru.
- **Boss Arena & Challenge**: Terbuka ketika topik mencapai penguasaan $\ge 80\%$, menghadapkan pemain dengan soal kompleks tingkat lanjut dan pertarungan HP Boss.

### 2. AI Brain & Adaptive Learning
- **Adaptive Difficulty**: AI memantau akurasi jawaban terkini:
  - Performa konsisten bagus $\rightarrow$ kesulitan ditingkatkan (Easy $\rightarrow$ Medium $\rightarrow$ Hard).
  - Mengalami kesulitan $\rightarrow$ AI menurunkan tingkat kesulitan atau memberikan soal *Remedial*.
  - Kesalahan berulang pada topik tertentu $\rightarrow$ AI merekomendasikan sesi *Review Konsep*.
- **Pembahasan Konseptual**: Setiap soal dilengkapi penjelasan komprehensif, langkah penyelesaian, dan tips mengingat konsep kunci.
- **Analisis Kelemahan**: Halaman Progres memberikan diagnosis cerdas mengenai topik yang paling membutuhkan latihan ulang.

### 3. Audio & Visual Effects (Web Audio API)
- Efek suara retro-game (jawaban benar, salah, level up, boss victory) disintesis secara langsung menggunakan **Web Audio API** bawaan browser (100% mandiri, bebas latensi, tanpa file audio eksternal yang rawan rusak).
- Animasi partikel confetti, XP bounce, dan floating indicators.

### 4. Responsif & Aksesibilitas
- Tampilan kartu modern bergaya RPG edukatif (clean, modern, tidak bising).
- Mendukung penuh resolusi Desktop, Tablet, dan Smartphone (Mobile-Friendly).
- LocalStorage persistence: Progres otomatis tersimpan di peramban pengguna.

---

## 📂 Struktur Proyek
```text
/
├── index.html         # Struktur markup semantik utama antarmuka game
├── style.css          # Desain sistem, tema gamifikasi, animasi, dan layout responsif
├── script.js          # Mesin game, state manager, audio synth, adaptive AI logic & bank soal
├── assets/            # Aset statis pendukung (ikon, logo SVG)
└── README.md          # Dokumentasi teknis, arsitektur, dan panduan deployment
```

---

## 🚀 Cara Menjalankan Secara Lokal

Website ini dibangun menggunakan teknologi web murni (**Vanilla HTML5, CSS3, dan Modern JavaScript ES6+**), sehingga **tidak memerlukan instalasi build tools (seperti Node.js, Webpack, dsb)**.

### Opsi 1: Buka Langsung di Browser
1. Clone atau unduh repositori ini ke komputer Anda:
   ```bash
   git clone https://github.com/USERNAME/study-game.git
   cd study-game
   ```
2. Klik dua kali file `index.html` atau klik kanan lalu pilih **Open with Google Chrome / Firefox / Edge / Safari**.

### Opsi 2: Menggunakan Local Development Server (Disarankan)
Untuk simulasi lingkungan hosting produksi:
- **Menggunakan Python 3**:
  ```bash
  python3 -m http.server 8000
  ```
  Lalu buka `http://localhost:8000` pada peramban Anda.
- **Menggunakan VS Code Live Server**:
  Klik kanan pada `index.html` dan pilih **Open with Live Server**.

---

## 🌐 Cara Melakukan Deployment ke GitHub Pages

Proyek ini sangat kompatibel dengan **GitHub Pages** karena berstatus static web:

1. **Buat Repositori Baru di GitHub**:
   - Beri nama repositori, contoh: `study-game`.
   - Pilih visibilitas **Public**.
2. **Push Kode ke GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Study Game interactive learning platform"
   git branch -M main
   git remote add origin https://github.com/USERNAME/study-game.git
   git push -u origin main
   ```
3. **Aktifkan GitHub Pages**:
   - Buka tab **Settings** di repositori GitHub Anda.
   - Pilih menu **Pages** di bilah navigasi samping kiri.
   - Pada bagian **Build and deployment > Source**, pilih **Deploy from a branch**.
   - Pada dropdown Branch, pilih `main` dan folder `/ (root)`.
   - Klik **Save**.
4. **Website Siap Digunakan**:
   - Dalam 1–2 menit, GitHub Pages akan menerbitkan tautan web publik Anda di format:
     `https://USERNAME.github.io/study-game/`

---

## 🤖 Integrasi AI & Arsitektur Keamanan (AI API Integration)

Aplikasi ini telah dilengkapi dengan **Adaptive AI Simulator** bawaan yang menyimulasikan penalaran pembuatan soal adaptif, grading, dan analisis kelemahan secara offline.

Jika Anda ingin menghubungkan Study Game dengan model AI generatif pihak ketiga (seperti Gemini API atau OpenAI API) untuk membuat soal dinamis tanpa batas:

### ⚠️ PERINGATAN KEAMANAN:
**Jangan pernah menaruh API Key langsung di dalam file `script.js` atau kode frontend publik!**
Kode frontend dapat dibaca oleh siapa saja melalui browser *Inspect / Developer Tools*, sehingga kunci API Anda dapat dicuri dan disalahgunakan.

### Arsitektur yang Direkomendasikan:
1. **Frontend (`script.js`)**:
   Hanya mengirim request parameter belajar (mata pelajaran, topik, tingkat kesulitan, riwayat kesalahan) ke backend endpoint pribadi:
   ```javascript
   // Contoh arsitektur panggilan yang aman
   const response = await fetch('/api/generate-question', {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify({ subject, topic, difficulty, weaknessContext })
   });
   ```
2. **Backend Proxy / Serverless Function (Vercel Functions, Cloudflare Workers, Netlify Functions, atau Node.js)**:
   - Menyimpan `AI_API_KEY` di **Environment Variable** yang aman di server.
   - Menghubungi API AI, memvalidasi prompt dan format respons JSON.
   - Mengembalikan data soal yang bersih ke aplikasi Study Game.

---

## 💾 Struktur Data (LocalStorage)
Data pengguna disimpan di peramban dengan skema:
```json
{
  "profile": { "name": "Pelajar Tangguh", "avatar": "🧙‍♂️" },
  "stats": {
    "totalXp": 120,
    "level": 2,
    "streak": 3,
    "bestStreak": 7,
    "totalAnswered": 15,
    "correctCount": 12
  },
  "mastery": {
    "math_algebra": 85,
    "math_geometry": 40,
    "science_physics": 60
  },
  "history": [
    {
      "timestamp": 1727400000000,
      "subject": "Matematika",
      "topic": "Aljabar & Persamaan",
      "difficulty": "Hard",
      "question": "Jika 3x + 7 = 22, berapakah nilai x?",
      "isCorrect": true,
      "xpEarned": 30
    }
  ]
}
```
Skema ini sangat mudah dimigrasikan ke database backend (seperti Firebase Firestore, Supabase, PostgreSQL, atau MongoDB) saat aplikasi dikembangkan ke tahap multi-user cloud.
